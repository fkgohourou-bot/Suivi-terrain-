# Mon suivi terrain : installer l'application

Ce dossier contient la version installable (PWA) de l'application.
Une fois mise en ligne, elle a une adresse fixe, une icône sur l'écran d'accueil,
et elle fonctionne sans internet.

## 1. Mettre le dossier en ligne (une seule fois)

### Option A : Netlify (le plus simple, depuis un ordinateur)
1. Créez un compte gratuit sur https://app.netlify.com
2. Allez sur https://app.netlify.com/drop
3. Glissez-déposez ce dossier entier (celui qui contient index.html).
4. Netlify vous donne une adresse du type https://nom-au-hasard.netlify.app
   Vous pouvez la renommer dans les réglages du site.

### Option B : GitHub Pages
1. Créez un compte gratuit sur https://github.com
2. Créez un dépôt (repository), par exemple "suivi-terrain".
3. Envoyez tous les fichiers de ce dossier (bouton "Add file", puis "Upload files").
4. Dans Settings, puis Pages : choisissez la branche "main" et enregistrez.
5. L'adresse sera https://votre-nom.github.io/suivi-terrain/

## 2. Installer sur le téléphone
1. Ouvrez l'adresse dans Chrome.
2. Menu ⋮, puis "Installer l'application" (ou "Ajouter à l'écran d'accueil").
3. L'icône "Suivi terrain" apparaît sur votre écran d'accueil.

## 3. Récupérer vos données actuelles
Vos données actuelles sont dans l'ancien fichier suivi_terrain.html.
1. Ouvrez l'ancien fichier, Réglages (roue dentée), onglet Sauvegarde.
2. Touchez "Télécharger le fichier de sauvegarde".
3. Ouvrez l'application installée, Réglages, onglet Sauvegarde.
4. "Restaurer depuis un fichier de sauvegarde" et choisissez le fichier.
5. Vérifiez vos chiffres, puis mettez un code dans l'onglet Code.

## 4. Mettre à jour plus tard
Remplacez les fichiers en ligne par ceux de la nouvelle version (même adresse).
Vos données restent dans le téléphone : l'adresse ne change pas.
Faites quand même une sauvegarde avant chaque mise à jour.

## Bon à savoir
- Désinstaller l'application ou effacer les données de Chrome pour ce site efface vos données.
  Gardez des fichiers de sauvegarde récents.
- Le code à 4 chiffres protège l'écran, il ne chiffre pas les données.
